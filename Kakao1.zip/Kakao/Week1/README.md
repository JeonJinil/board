## Open_chaeting_room

https://programmers.co.kr/learn/courses/30/lessons/42888

## Failure_rate

https://programmers.co.kr/learn/courses/30/lessons/42889
