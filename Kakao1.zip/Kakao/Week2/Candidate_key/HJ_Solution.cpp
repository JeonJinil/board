#include <string>
#include <vector>

using namespace std;

int solution(vector<vector<string>> relation) {
    int answer = 0;
    //NYI
    return answer;
}
