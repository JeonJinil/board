#include <string>
#include <vector>

using namespace std;

int solution(string word, vector<string> pages) {
    int answer = 0;
    //NYI
    return answer;
}
