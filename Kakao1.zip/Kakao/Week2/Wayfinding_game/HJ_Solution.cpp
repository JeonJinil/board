#include <string>
#include <vector>

using namespace std;

vector<vector<int>> solution(vector<vector<int>> nodeinfo) {
    vector<vector<int>> answer;
    //NYI
    return answer;
}
