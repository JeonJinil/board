#include <string>
#include <vector>

using namespace std;

string solution(string p) {
    string answer = "";
    //NYI
    return answer;
}
