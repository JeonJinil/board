#include <string>
#include <vector>

using namespace std;

int solution(string s) {
    int answer = 0;
    //NYI
    return answer;
}
