#include <string>
#include <vector>

using namespace std;

int map[60][60];
int M, N;

void moveRight()
{
	for (int i = 0; i < 60; i++)
	{
		for (int j = 59; j > 0; j--)
			map[i][j] = map[i][j - 1];
		map[i][0] = 0;
	}
}

void moveDown()
{
	for (int j = 0; j < 60; j++)
	{
		for (int i = 59; i > 0; i--)
			map[i][j] = map[i - 1][j];
		map[0][j] = 0;
	}
}

void rotate() // Clockwise
{
	int originMap[60][60];
	for (int i = 0; i<60; i++)
		for (int j = 0; j<60; j++)
			originMap[i][j] = map[i][j];

	for (int i = 0; i < M; i++)
		for (int j = 0; j < M; j++)
			map[j][M - 1 - i] = originMap[i][j];
}


bool solution(vector<vector<int>> key, vector<vector<int>> lock)
{
	M = key.size(); N = lock.size();
	for (int i = 0; i < M; i++)
		for (int j = 0; j < M; j++)
			map[i][j] = key[i][j];

	for (int k = 0; k < 4; k++, rotate())
	{
		int originMapI[60][60];
		for (int i = 0; i < 60; i++)
			for (int j = 0; j < 60; j++)
				originMapI[i][j] = map[i][j];

		for (int i = 0; i < 2 * (M - 1) + (N - 1); i++, moveDown())
		{
			int originMapJ[60][60];
			for (int i = 0; i < 60; i++)
				for (int j = 0; j < 60; j++)
					originMapJ[i][j] = map[i][j];

			for (int j = 0; j < 2 * (M - 1) + (N - 1); j++, moveRight())
			{
				bool nextStep = false;
				for (int m = 0; m < N; m++)
				{
					for (int n = 0; n < N; n++)
					{
						if (lock[m][n] == 0) // �ڹ��� Ȩ
						{
							if (map[M - 1 + m][M - 1 + n] == 0) // ���� ����
							{
								nextStep = true;
								break;
							}
						}
						else // �ڹ��� ����
						{
							if (map[M - 1 + m][M - 1 + n] == 1) // ���� Ȩ
							{
								nextStep = true;
								break;
							}
						}
						if (m == N - 1 && m == n)
							return true;
					}
					if (nextStep)
						break;
				}
			}
			for (int i = 0; i < 60; i++)
				for (int j = 0; j < 60; j++)
					map[i][j] = originMapJ[i][j];
		}

		for (int i = 0; i < 60; i++)
			for (int j = 0; j < 60; j++)
				map[i][j] = originMapI[i][j];
	}

	return false;
}